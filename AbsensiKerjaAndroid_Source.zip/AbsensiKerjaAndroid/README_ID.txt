ABSENSI KERJA ANDROID - SOURCE PROJECT

Proyek ini membungkus aplikasi absensi HTML menjadi aplikasi Android WebView offline bernama "Absensi Kerja".

PENTING: Ini source project, bukan APK siap pasang. APK harus dikompilasi.

CARA TANPA KOMPUTER (build di cloud menggunakan GitHub Actions):
1. Dari HP, buat repository baru di https://github.com/new.
2. Ekstrak ZIP ini di HP menggunakan aplikasi pengelola file.
3. Unggah isi folder proyek ke repository GitHub, termasuk folder tersembunyi .github/workflows/build-apk.yml.
4. Buka tab Actions pada repository dan jalankan workflow "Build APK Absensi Kerja" (Run workflow). Workflow juga berjalan saat commit ke main/master.
5. Setelah selesai, buka hasil workflow dan unduh artifact bernama AbsensiKerja-APK. Ekstrak ZIP artifact untuk mendapatkan app-debug.apk.
6. Buka APK di HP dan izinkan pemasangan aplikasi dari sumber ini jika Android memintanya.

Alternatif termudah bila proses GitHub terlalu rumit: minta bantuan orang yang memiliki komputer untuk membuka proyek ini di Android Studio lalu Build APK.

CATATAN APLIKASI:
- Data absensi tersimpan lokal di aplikasi; menghapus data aplikasi atau uninstall bisa menghapus data tersebut.
- APK debug untuk pemasangan pribadi, bukan rilis Play Store.
- Verifikasi kalender libur nasional dan aturan lembur dengan HR sebelum digunakan untuk catatan resmi.
